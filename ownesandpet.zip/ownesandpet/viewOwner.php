<?php
 error_reporting(0);
 $id=$_SESSION['id'];
$dbservername="localhost";
$dbuser="root";
$dbpass="";
$dbname="webs";
$conn=mysqli_connect($dbservername,$dbuser,$dbpass,$dbname);
$query = "SELECT * FROM  users";
$data = mysqli_query($conn,$query);
$total = mysqli_num_rows($data);
//$results=mysqli_fetch_assoc($data);
$query22="SELECT phptol FROM users";

if(!($result2=mysqli_query($conn,$query22)))
die("<p>the qurey error</p>");
$row2=mysqli_fetch_all($result2,MYSQLI_ASSOC);

?>
   <?php
$results=mysqli_fetch_assoc($data)

        ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="profile_style.css">
        <title>Your profile</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"rel="stylesheet"/> 
        <script src="https://kit.fontawesome.com/493718cddd.js" crossorigin="anonymous"></script>

   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"rel="stylesheet"/> 

    <link rel="preconnect" href="https://fonts.googleapis.com">
   
    <link href="https://fonts.googleapis.com/css2?family=Shizuru&display=swap" rel="stylesheet">
    
   
        <link rel="stylesheet" href="Header and Footer.css">
        
    </head>
    <body>
        <header>
       
            <a href="#"  class="logo"><img src="logo.png" alt="logo" height="50rem" ><span style="font-size: 40px;">WEBETS</span></a>
         
            <input type="checkbox" id="menu-bar">
            <label for="menu-bar" class="fas fa-bars"></label>
        
            <nav class="navbar">
                <ul class="nav-list">
                    <li  ><a href="home-owner.html" >Home</a>
                        
                      </li>
                      
                      
                   <li><a href="pageone.html">Services</a></li> 
                   <li><a href="AboutUs.html">About Us</a></li> 
                   <li class="move-right-btn" ><a href="#"id="profile"><i class="fas fa-user" ></i></a>
                    <ul class="sub-menu" id="sub-menu-arrow2"> 
                        <li ><a href="Owner_profile.html">View Profile</a></li>
                        <li><a href="My_pets_list.html">Pets</a></li>
                        <li><a href="main.html">Sign Out</a></li>
                      </ul></li>
                  </ul>
                
                <!-- ****if you're working on a pet owner view replace <i class="fa-solid fa-user-doctor"> with <i class="fa-solid fa-user"></i>  -->
        
        
            </nav>
        
        </header>
    <section>
        <!--<div class="oo"><a href="My_pets_list.html"><strong>Back</strong></a></div>-->
        <div class="iconsa" >  
<?php echo   '<a href="updatePet.php?pid=' .  $results['id'].'"> <img src="Yellow_Brown_Line_Minimalist_Logo_-removebg-preview.png" ></a>';?>
           
       </div>
       <div class="icons2a" >  
    
    <?php echo   '<a href="display.php?pid=' .  $results['id'].'"> <img src="back-removebg-preview.png" ></a>';?>  
       
   </div>
        <div class="account">
     
           <form action="" method="post"></form>
            
           <div class="left">
           <?php foreach($row2 as $appoi){  ?>
       <img   src="data:image/jpeg;base64,<?php echo base64_encode($appoi['phptol']); ?>"  >  
    <?php }?>
               <h4><?php echo $results['fname'];?></h4>
<p>Owner</p>
           </div>
            <div class="right">
                <div class="info">
                    <h3>My profile</h3>
                    <div class="info_data">
                         <div class="data">
                            <h4>First name</h4>
                            <p ><?php echo $results['fname'];?></p>
                         </div>
                         <div class="data">
                           <h4>Last name</h4>
                           <p ><?php echo $results['lname'];?></p>
                      </div>
                      <div class="data">
                        <h4>Email</h4>
                        <p ><?php echo $results['email'];?></p>
                   </div>
                   <div class="data">
                    <h4>Gender</h4>
                    <p ><?php echo $results['gender'];?></p>
               </div>
               <div class="data">
                <h4>Phone number</h4>
                <p ><?php echo $results['phone'];?></p>
           </div>
                    </div>
                </div>



            </div>
            
        </div>
      
        <!-- <div class="pic"><img src="IMG_3875-removebg-preview.png" alt=""></div>
       <div class="o"><a  href="Edit_owner.html"><strong>Account Settings </strong></a></div>
        <div class="pic2"><img src="m.png" alt=""></div>-->
    </section>
    <div class="footer">
        <div class="box-container">
            
            <div class="box">
                <h3>Quick links</h3>
                <a href="Owner_profile.html">Home</a>
                <a href="pageone.html">Services</a>
                <a href="AboutUs.html">About US</a>    
            </div>
            <div class="box">
                <h3>Find Us</h3>  
              
                <div class="info">
                    
                    <i class="fas fa-envelope"></i>
                                <a href="mailto:StudentID@student.ksu.edu.sa">Email</a>
                </div>
               
            </div>
            <div class="box">
                <h3>Contact Information</h3>
                <div class="info">
                    <i class="fas fa-phone"></i>
                    <p>+123-456-789 <br> +111-222-3333</p>
                </div>
                   
            </div>
            
        </div>
        <h1 class="credit">&copy; copyright @ 2022 by software Engineers</h1>
    </div>
    



    </body>
</html>
