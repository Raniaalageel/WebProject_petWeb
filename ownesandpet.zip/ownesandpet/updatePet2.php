<php

<?php
	$host="localhost";   $duus="root";
    $dbp="";     $dbname="webs";
    if(!($db2=mysqli_connect($host,$duus,$dbp,$dbname)))
    die("<p>the connection error</p>");


    if(!isset($_GET['id'] )){
        die('id not provided');
    
    } 
    $id=$_GET['id'];
    if(isset($_POST['update'])){


        $name = $_POST['name'];
        $gender = $_POST['gender'];
        $status =$_POST['stat'];
        $vaccination_ = $_POST['vac'];
        $birth_ = $_POST['date'];
        $breed = $_POST['breed'];
        $medical = $_POST['med'];
        $query2 = "SELECT * FROM  Pet where id= '$id'";

if($_FILES['photo']['size']>0)  {
    $phptol2=$_FILES['photo']['tmp_name'];
    $phptol2=addslashes(file_get_contents( $phptol2));  


if( mysqli_query($db2,"UPDATE  pet set gender='  $gender',   photopet ='   $phptol2' , 	status_=' $status',vaccination_list='$vaccination',birth_date=' $birth_ ',fullname='   $name',breed='$breed',medical_history='$medical'  where  id='$id'"))
echo '<script>alert("pet is Updated succsefully")</script>';

 header('location:view2.php');
}
else{
   

    $name = $_POST['name'];
        $gender = $_POST['gender'];
        $status =$_POST['stat'];
        $vaccination_ = $_POST['vac'];
        $birth_ = $_POST['date'];
        $breed = $_POST['breed'];
        $medical = $_POST['med'];

        if( mysqli_query($db2,"UPDATE  pet set gender='  $gender', 	status_=' $status',vaccination_list='$vaccination',birth_date=' $birth_ ',fullname='   $name',breed='$breed',medical_history='$medical'  where  id='$id'"))

    echo '<script>alert("pet is Updated succsefully")</script>';

    header('location:view2.php');

}

}

/////
   
        
  
    mysqli_close($db2);
?>


?>


